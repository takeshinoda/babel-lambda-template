'use strict';

var _config = require('./config');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Babel6 export syntax bug?
exports.handler = function (event, context) {
  console.log(event);
  context.succeed('success');
};